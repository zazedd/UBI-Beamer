# Beamer Template for UBI

A simple LaTeX template for presentations in University of Beira Interior.
